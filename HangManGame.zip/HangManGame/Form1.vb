﻿Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim stWord As String
        Dim Objrandom As New Random
        Dim intRandom As Integer = 0
        Dim inteller As Integer
        Dim arrWord(3) As String
        Dim present As Boolean
        Dim wrong As Integer = 1
        Dim guesschar As Char
        Const letters As String = "abcdefghijklmnopqrstuvwxyz"
        Label1.Text = String.Empty
        PictureBox1.Visible = False
        ListBox1.Items.Clear()
        intRandom = Objrandom.Next(1, 4)
        arrWord(1) = "beauty"
        arrWord(2) = "cat"
        arrWord(3) = "super"
        stWord = arrWord(intRandom)
        Select Case intRandom
            Case 1
                Me.Label1.Text = "______"
            Case 2
                Me.Label1.Text = "___"
            Case 3
                Me.Label1.Text = "_____"
        End Select
        stWord.ToCharArray()

        Do
            guesschar = InputBox("Give a letter from A-Z, and try to guess the right answer ").ToLower
            If InStr(letters, guesschar) = 0 Then
                MessageBox.Show("you can only use letters ")
                Exit Do

            Else

                If ListBox1.Items.Contains(guesschar) = False Then
                    present = False
                    ListBox1.Items.Add(guesschar)

                    For inteller = 0 To arrWord(intRandom).Length - 1

                        If stWord(inteller) = guesschar Then
                            Me.Label1.Text = Label1.Text.Remove(inteller, 1)
                            Me.Label1.Text = Label1.Text.Insert(inteller, guesschar)
                            present = True
                        End If
                    Next
                    If present = False Then
                        PictureBox1.Visible = True
                        PictureBox1.Image = ImageList1.Images(wrong)
                        wrong += 1
                    End If
                Else
                    MessageBox.Show("Letter has already been used , choose another one !")

                End If
            End If


        Loop Until Label1.Text = arrWord(intRandom) Or wrong = 7
        If wrong = 7 Then
            MessageBox.Show("you lost the game , to play again press the button ,the word you had to find was " & arrWord(intRandom).ToString, "LOST")
        ElseIf Label1.Text = arrWord(intRandom) Then
            MessageBox.Show("YOU WON ,well done mate ,to guess the next word press the button ", "WON")
        End If

    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
